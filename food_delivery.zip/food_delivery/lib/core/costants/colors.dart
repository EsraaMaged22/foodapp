import 'dart:ui';

class AppColors {
  static const Color primaryRed = Color(0xffef2a39);
  static const Color accentRed = Color(0xfff86873);

}